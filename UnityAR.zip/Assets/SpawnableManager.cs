using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.UI;

public class SpawnableManager : MonoBehaviour
{
    [SerializeField]
    ARRaycastManager m_RaycastManager;
    List<ARRaycastHit> m_Hits = new List<ARRaycastHit>();
    [SerializeField]
    GameObject colorPicker;
    [SerializeField]
    GameObject spawnablePrefab;


    GameObject spawnedObject;
    Button colorButton;
    Button button;



    public FlexibleColorPicker fcp;
    public Material material;

    
    bool buttonPressed = false;
    bool pickerShown = false;

    // Start is called before the first frame update
    void Start()
    {
        colorButton = GameObject.Find("ColorButton").GetComponent<Button>();
        button = GameObject.Find("Button").GetComponent<Button>();
        colorButton.gameObject.SetActive(false);
        colorPicker.SetActive(false);
        spawnedObject = null;
        button.onClick.AddListener(ButtonPressed);
        colorButton.onClick.AddListener(ColorButtonPressed);
    }

    // Update is called once per frame
    void Update()
    {
        material.color = fcp.color;

        if (Input.touchCount == 0)
            return;

        if (m_RaycastManager.Raycast(Input.GetTouch(0).position, m_Hits))
        {
            //if (Input.GetTouch(0).phase == TouchPhase.Began)
            if(buttonPressed)
            {
                SpawnPrefab(m_Hits[0].pose.position);
                buttonPressed = false;
            }
            else if (Input.GetTouch(0).phase == TouchPhase.Moved && spawnedObject != null)
            {
                spawnedObject.transform.position = m_Hits[0].pose.position;
            }
            if (Input.GetTouch(0).phase == TouchPhase.Ended)
            {
                spawnedObject = null;
            }
        }

        
    }

    private void SpawnPrefab(Vector3 spawnPosition)
    {
        spawnedObject = Instantiate(spawnablePrefab, spawnPosition, Quaternion.identity);
    }

    private void ButtonPressed()
    {
        buttonPressed = true;
        colorButton.gameObject.SetActive(true);
        
    }

    private void ColorButtonPressed()
    {
        if (!pickerShown)
        {
            Debug.Log("nyt pit�is aueta v�ri ikkuna");
            colorPicker.SetActive(true);
            pickerShown = true;
            colorButton.GetComponentInChildren<Text>().text = "done";
            
        }
        else if (pickerShown)
        {
            colorPicker.SetActive(false);
            colorButton.GetComponentInChildren<Text>().text = "COLOR!!";
            pickerShown = false;
        }
    }
}